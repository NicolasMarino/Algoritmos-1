
#include <iostream>
using namespace std;
#include "Pruebas.h"

int main() {
	Pruebas();

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
	//system("pause");
#endif

	return 0;
}
