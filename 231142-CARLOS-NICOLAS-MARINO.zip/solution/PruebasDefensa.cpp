#include "PruebasDefensa.h"

#ifndef PRUEBASDEFENSA_CPP
#define PRUEBASDEFENSA_CPP

void PruebasDefensa() {
	
	int nroPrueba = 1;
	int correctos = 0, error = 0;
	int correctosTotal = 0, errorTotal= 0;


	
	cout << "----------------------------------------------"<<endl;
	cout << "----------------------------------------------"<<endl;
	cout << "PRUEBAS CORRECTAS: " << correctosTotal << endl;
	cout << "PRUEBAS INCORRECTAS: " << errorTotal << endl;
	
}

#endif