#ifndef PRUEBASDEFENSA_H
#define PRUEBASDEFENSA_H

#include "FuncAux.h"
#include "PruebasAuxDefensa.h"

void PruebasDefensa();

#endif