#pragma once

#include "PruebasAuxComienzo.h"
#include "FuncAux.h"

void PruebasComienzo();

