#ifndef PRUEBAS_H
#define PRUEBAS_H

#include "ManejadorSalidaPrueba.h"
#include "FuncAux.h"
#include "PruebasPropias.h"
#include "PruebasDefensa.h"
#include "PruebasComienzo.h"
#include "PruebasListas.h"
#include "PruebasArboles.h"

void Pruebas();

#endif