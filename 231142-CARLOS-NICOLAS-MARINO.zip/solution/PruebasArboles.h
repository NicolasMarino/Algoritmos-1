#pragma once

#include "PruebasAuxArboles.h"
#include "FuncAux.h"

void PruebasArboles();

