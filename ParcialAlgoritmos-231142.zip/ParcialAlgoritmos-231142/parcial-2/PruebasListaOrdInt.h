#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "ListaOrdInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasListaOrdInt(Prueba* pruebaConcreta);
