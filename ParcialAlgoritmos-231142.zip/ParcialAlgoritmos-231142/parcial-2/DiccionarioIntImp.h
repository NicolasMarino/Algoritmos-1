#pragma once

#ifdef DICCIONARIO_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>
#include "ListaOrdInt.h" // QUITAR AL ENTREGAR

struct _cabezalDiccionarioInt;
typedef struct _cabezalDiccionarioInt* DiccionarioInt;

#endif
