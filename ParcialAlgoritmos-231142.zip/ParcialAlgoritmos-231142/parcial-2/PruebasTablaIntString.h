#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "TablaIntString.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasTablaIntString(Prueba* pruebaConcreta);
