#include "TablaIntString.h"

#ifdef TABLA_INT_STRING_IMP

struct _cabezalTablaIntString {
	// NO IMPLEMENTADO
};

TablaIntString crearTablaIntString(unsigned int esperados) {
	// NO IMPLEMENTADO
	return NULL;
}


void agregar(TablaIntString& t, int d, const char* r) {
	// NO IMPLEMENTADO
}

bool estaDefinida(TablaIntString t, int d) {
	// NO IMPLEMENTADO
	return NULL;
}

char* recuperar(TablaIntString t, int d) {
	// NO IMPLEMENTADO
	char* ret = new char[1];
	ret[0] = '\0';
	return ret;
}

void borrar(TablaIntString& t, int d) {
	// NO IMPLEMENTADO
}

int elemento(TablaIntString t) {
	// NO IMPLEMENTADO
	return 0;
}

bool esVacia(TablaIntString t) {
	// NO IMPLEMENTADO
	return true;
}

unsigned int cantidadElementos(TablaIntString t) {
	// NO IMPLEMENTADO
	return 0;
}

void destruir(TablaIntString& t) {
	// NO IMPLEMENTADO
}

TablaIntString clon(TablaIntString t) {
	// NO IMPLEMENTADO
	return NULL;
}

#endif