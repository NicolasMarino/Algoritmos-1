#pragma once

#ifdef MULTISET_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>
#include "FuncAux.h" // QUITAR AL ENTREGAR

struct _cabezalMultisetInt;
typedef struct _cabezalMultisetInt* MultisetInt;

#endif
