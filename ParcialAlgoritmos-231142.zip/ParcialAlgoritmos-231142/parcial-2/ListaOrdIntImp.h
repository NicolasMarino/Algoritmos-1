#pragma once

#ifdef LISTA_ORD_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>
#include "FuncAux.h" // QUITAR AL ENTREGAR

struct _cabezalListaOrdInt;
typedef struct _cabezalListaOrdInt* ListaOrdInt;

#endif
