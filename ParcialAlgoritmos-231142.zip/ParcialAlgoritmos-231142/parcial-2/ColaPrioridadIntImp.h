#pragma once

#ifdef COLAPRIORIDAD_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>

struct _cabezalColaPrioridadInt;
typedef struct _cabezalColaPrioridadInt *ColaPrioridadInt;

#endif
