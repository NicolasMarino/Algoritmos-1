#pragma once

#include "FuncAux.h"
#include "FuncAuxTAD.h"
#include "Ejercicios.h"


