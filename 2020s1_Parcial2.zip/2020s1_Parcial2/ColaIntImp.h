#pragma once

#ifdef COLA_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>
#include "FuncAux.h"

struct _cabezalColaInt;
typedef struct _cabezalColaInt *ColaInt;

#endif
