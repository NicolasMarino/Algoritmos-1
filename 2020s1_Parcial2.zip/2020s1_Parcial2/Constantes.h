#pragma once

#include <iostream>
using namespace std;

 ///////////////////////////
// ---------------------- //
// DEFINICIONES DE TIPOS  //
// ---------------------- //////////////////////////////

#include "TipoRetorno.h"


