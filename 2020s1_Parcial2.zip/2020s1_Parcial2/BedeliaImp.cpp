#include "Bedelia.h"

#ifdef BEDELIA_IMP

// Poner un nombre acorde a _xxxxx (en BedeliaImp.cpp y BedeliaImp.h)
struct _xxxxx {
	// NO IMPLEMENTADO
};

Bedelia crearBedelia(unsigned int cantEstudiantes) {
	// NO IMPLEMENTADA
	return NULL;
}

void actualizarEstudiante(Bedelia& b, const char* nombreE, unsigned int id) {
	// NO IMPLEMENTADA
}

void actualizarMateria(Bedelia& b, const char* nombreA, unsigned int id) {
	// NO IMPLEMENTADA
}

void actualizarExamen(Bedelia& b, unsigned int nroE, unsigned int nroA, const char* fecha, int nota) {
	// NO IMPLEMENTADA
}

void escolaridadEstudiante(Bedelia b, unsigned int nroE) {
	// NO IMPLEMENTADA
}

void estadisticaMateria(Bedelia b, unsigned int nroA) {
	// NO IMPLEMENTADA
}

void destruir(Bedelia& b) {
	// NO IMPLEMENTADA
}

#endif

