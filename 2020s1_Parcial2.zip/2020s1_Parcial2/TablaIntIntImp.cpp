#include "TablaIntInt.h"

#ifdef TABLA_INT_INT_IMP

struct _cabezalTablaIntInt {
	// NO IMPLEMENTADO
};

TablaIntInt crearTablaIntInt(unsigned int esperados) {
	// NO IMPLEMENTADO
	return NULL;
}


void agregar(TablaIntInt& t, int d, int r) {
	// NO IMPLEMENTADO
}

bool estaDefinida(TablaIntInt t, int d) {
	// NO IMPLEMENTADO
	return NULL;
}

int recuperar(TablaIntInt t, int d) {
	return 0;
}

void borrar(TablaIntInt& t, int d) {
	// NO IMPLEMENTADO
}

int elemento(TablaIntInt t) {
	// NO IMPLEMENTADO
	return 0;
}

bool esVacia(TablaIntInt t) {
	// NO IMPLEMENTADO
	return true;
}

unsigned int cantidadElementos(TablaIntInt t) {
	// NO IMPLEMENTADO
	return 0;
}

void destruir(TablaIntInt& t) {
	// NO IMPLEMENTADO
}

TablaIntInt clon(TablaIntInt t) {
	// NO IMPLEMENTADO
	return NULL;
}

#endif