#pragma once

#ifdef BEDELIA_IMP

#include <iostream>
using namespace std;
#include <assert.h>

// Poner un nombre acorde a _xxxxx (en BedeliaImp.cpp y BedeliaImp.h)
struct _xxxxx;
typedef struct _xxxxx* Bedelia;

#endif
