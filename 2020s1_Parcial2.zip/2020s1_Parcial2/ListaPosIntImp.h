#pragma once

#ifdef LISTA_POS_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>
#include "FuncAux.h" // QUITAR AL ENTREGAR

struct _cabezalListaPosInt;

typedef struct _cabezalListaPosInt* ListaPosInt;


#endif
